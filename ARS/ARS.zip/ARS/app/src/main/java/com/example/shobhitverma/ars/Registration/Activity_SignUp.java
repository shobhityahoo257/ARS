package com.example.shobhitverma.ars.Registration;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.shobhitverma.ars.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Activity_SignUp extends AppCompatActivity {
    private FirebaseUser mUser;
    private FirebaseDatabase mdb;
    private DatabaseReference mref;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);
        System.out.println(FirebaseAuth.getInstance().getCurrentUser().getPhoneNumber());
        mref=FirebaseDatabase.getInstance().getReference().child()
    }

}