package com.example.shobhitverma.ars.Search;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import com.example.shobhitverma.ars.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class Activity_Home extends AppCompatActivity {
    private android.support.v7.widget.Toolbar mToolbar;
    private RecyclerView mRecyclerView;
    private DatabaseReference mFirebaseDatabase;
    private FirebaseRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        Query query= FirebaseDatabase.getInstance().getReference().child("rooms").limitToLast(50);



        FirebaseRecyclerOptions<Rooms> options=new FirebaseRecyclerOptions.Builder<Rooms>().setQuery(query,Rooms.class).build();
        mToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.home_app_bar_layout);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("ARS");

    }
}

